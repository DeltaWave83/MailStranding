var gameStarted = false;

function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  if(gameStarted === false)
    {
    background(220);
    fill('#F56B0A');
    rect(0,0,1000,1000);
    strokeWeight(2);
    stroke(0);
    fill('#1E37E9');
    textSize(100);
    text('Welcome to',250,175);
    text('Mail Stranding',200,275);
    textSize(40);
    text('WASD - Overworld movement',25, 375);
    text('Arrow keys - Cursor movement',25,   425);
    text('P - Opens pause screen',25, 475);
    text('Spacebar - Selects action in battle',25, 525);
    text('Backspace - Goes back on the battle screen',25, 575);
    text('??? - Secret combo of keys for you to figure out',25, 625);
    }
}