function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  //if((easyEnemyHealth == 0) && (hardEnemyHealth == 0))
    {
    background(220);
    fill(0);
    rect(0,0,1000,1000);
    strokeWeight(2);
    stroke(0);
    fill(225);
    textSize(100);
    text('Congratulations',150,175);
    text('You Won',290,375);
    text('Nice Job',300,575);
    }
}