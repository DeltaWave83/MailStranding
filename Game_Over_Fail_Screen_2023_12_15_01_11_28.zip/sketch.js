function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  if(playerHealth == 0)
    {
    background(220);
    fill(0);
    rect(0,0,1000,1000);
    strokeWeight(2);
    stroke(0);
    fill(225);
    textSize(100);
    text('Game Over',250,175);
    text('Press Play',265,375);
    text('To Try Again',225,575);
    }
}