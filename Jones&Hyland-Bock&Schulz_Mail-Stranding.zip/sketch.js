new p5();
var inBattle = 8;
var previousinBattle=0;
//state 1 is selecting move, state 2 is selecting enemy, state 3(?) is player damage phase
//state 0 is overworld movement, state 4 is enemy damage phase, state 5 is battle won, state 7 is game over, state 8 is title, state 9 is pause
var battleState = 8;
var previousBattleState=0;
var trianglePos = 1;
var power = 10;
var secretKey = 0;
var ultraSecret = 0;
var maxPlayerHealth= 50;
var playerHealth = 50;
var easyEnemyHealth = 30;
var currentEasyHealth=30;
var easyEnemyPower = 3;
var hardEnemyHealth = 70;
var currentHardHealth=70;
var hardEnemyPower = 7;
var damageDealt;
var enemiesKilled=0;
var topEnemyX=850;
var topEnemyY=250;
var bottomEnemyX=750;
var bottomEnemyY=400;
//following 2 probably aren't going to get used
var trianglePoints = [75,750,125,780,75,810];
var triangleTranslate1x=0;
//0 is idle, 1/2/3/4 are player moves
var moveSelect = 1;
var playerTimer=new Timer(3000);
var ptOn=false;
var enemyTimer=new Timer(3000);
var etOn=false;
var secretKillTimer=new Timer(3000);
var sktOn=false;
var battleWonTimer=new Timer(3000);
var bwtOn=false;
var enemyTurn=0;
var hasMoved=false;
var enemy1Xpos=200;
var enemy1Ypos=200;
var enemy2Xpos=800;
var enemy2Ypos=800;
var battleSetup=false;
var bye=0;

var highlightPosition = 0;
var wasPausePressed = false;
var inPauseScreen = 0;

let backimg;
let charimg;
let easyimg;
let hardimg;

let movingRight = false;
let movingLeft = false;
let movingUp = false;
let movingDown = false;

let xpos = 500;
let ypos = 500;
let speed = 5;


function preload(){
  backimg=loadImage("starbackground.png");
  charimg=loadImage("MailStrandedCharacterStraightFaceJetpack.gif");
  easyimg=loadImage("MailStrandedNormalPirate.gif");
  hardimg=loadImage("MailStrandedPirateDoubleEyePatchDoubleHook.gif");
}

function damageCalculate(x,y){
  var damage;
  if (moveSelect==1){
  damage = round(random(x*0.7,x*1.3));
  }
  if (moveSelect==2){
  damage = round(random(x,x*1.7));  
  }
  if (moveSelect==3){
  damage = x*0.8;  
  }
  var crit=random(1,10);
  if (crit<=y) {
    damage*=2;
  }
  return(damage);
}
//draw erase triangles according to movement
function eraseTriangle(){

  push();
  stroke(300);
  strokeWeight(10);
  triangle(75,750,125,780,75,810);
  triangle(525,750,575,780,525,810);
  triangle(525,850,575,880,525,910);
  triangle(75,850,125,880,75,910);
  pop();
}

//draws background, menu, and text as well as initial triangle
function setup() {
  print('^^^PLEASE IGNORE THE ABOVE WARNING, THE TIMER DOESN\'T WORK WITHOUT A SECOND IMPORT^^^');
  frameRate(1000);
  createCanvas(1000, 1000);
  playerTimer.pause();
  enemyTimer.pause();
  secretKillTimer.pause();
  battleWonTimer.pause();
}
//draws character,enemies, and health numbers, as well as descriptions(WIP) and battle end screen
function draw() {
  var playerTimerLeft=playerTimer.getRemainingTime();
  var enemyTimerLeft=enemyTimer.getRemainingTime();
  var secretKillTimerLeft=secretKillTimer.getRemainingTime();
  var battleWonTimerLeft=battleWonTimer.getRemainingTime();
  if(battleState==8&&inBattle==8){
    background(220);
    fill('#000000');
    rect(0,0,1000,1000);
    push();
    strokeWeight(2);
    stroke(0);
    fill('#717370');
    textSize(100);
    text('Welcome to',250,175);
    text('Mail Stranding',200,275);
    textSize(40);
    text('WASD - Overworld movement',25,375);
    text('Arrow keys - Cursor movement',25,425);
    text('P - Opens pause screen',25,475);
    text('Spacebar - Selects action in battle',25,525);
    text('U to select enemy in battle',25,575);
    text('Backspace - Goes back on the battle screen',25,625);
    text('??? - Secret combo of keys for you to figure out',25,675);
    textSize(60);
    text('H to start the game!!!',250,850);
    pop();
    }
  if (inBattle==0){
    
    image(backimg,0,0);
    
    // draw moving character
    push();
  fill(0, 0, 255);
  image(charimg,xpos,ypos);
  image(easyimg,enemy1Xpos,enemy1Ypos);
  image(easyimg,enemy2Xpos,enemy2Ypos);
    pop();
  
  // update moving character
    if (movingRight) {
    xpos += speed;
    }
  if (movingLeft) {
    xpos -= speed;
    }
  if (movingUp) {
    ypos -= speed;
    }
  if (movingDown) {
    ypos += speed;
    }
    
    if ((xpos>enemy1Xpos-75&&xpos<enemy1Xpos+75)&&(ypos>enemy1Ypos-125&&ypos<enemy1Ypos+125)){
      inBattle=1;
      battleState=1;
      currentEasyHealth=30;
      currentHardHealth=70;
    }
    if ((xpos>enemy2Xpos-75&&xpos<enemy2Xpos+75)&&(ypos>enemy2Ypos-125&&ypos<enemy2Ypos+125)){
      inBattle=1;
      battleState=1;
      currentEasyHealth=30;
      currentHardHealth=70;
    }
    
    
  }
  if (inBattle==1){
    if (currentEasyHealth<0){
      currentEasyHealth=0;
      topEnemyX=2000;
    topEnemyY=2000;
    }
    if (currentHardHealth<0){
      currentHardHealth=0;
      bottomEnemyX=2000;
    bottomEnemyY=2000;
    }
  
  if (battleState!=5||0){
    if (battleSetup==false&&bye!=1){
  background(220);
  fill(255);
  rect(50,700,900,250);
  push();
  stroke(0);
  fill(0);
  textSize(50);
  text('Punch',150,800);
  text('Gun',600,800);
  text('Flamethrower',150,900);
  text('Heal',600,900);
  pop();
  triangle(75,750,125,780,75,810);
  battleSetup=true;
    }
    push();
    noStroke();
    fill(220);
  rect(400,400,200,200);
    pop();
  push();
  image(charimg,150,300);
  pop();
  rect(10,275,90,50);
  push();
      stroke(0)
      fill(0);
      textSize(50);  
  text(playerHealth,20,320);
    pop();
  image(easyimg,topEnemyX,topEnemyY);
  rect(900,225,90,50);
    push();
      stroke(0)
      fill(0);
      textSize(50);
  text(currentEasyHealth,910,270);
    pop();
  image(hardimg,bottomEnemyX,bottomEnemyY);
  rect(800,375,90,50);
    push();
      stroke(0)
      fill(0);
      textSize(50);
  text(currentHardHealth,810,420);
    pop();
  if (trianglePos==1){
    describe('Lunge forward and punch the enemy! Deals 70-130% Damage, 30% crit rate',LABEL);
  }
  if (trianglePos==2){
    describe('Fire your trusty gun at the enemy! Deals 100-170% damage, 10% crit rate',LABEL);
  }
  if (trianglePos==3){
    describe('Pull out your flamethrower and burn the enemy! Deals 80% damage, 60% crit rate',LABEL);
  }
  if (trianglePos==4){
    describe('Grab some bandages and restore your health! Recovers 20% of your max HP',LABEL);
  }
  if (trianglePos==5){
    describe('Easy Enemy, '+currentEasyHealth+ ' HP',LABEL);
  }
    if (trianglePos==6){
    describe('Hard Enemy, '+currentHardHealth+ ' HP',LABEL);
  }
  
  if (playerTimerLeft<1500&&hasMoved==false){
    if (trianglePos==5&&moveSelect!=4){
      push();
      stroke(0)
      fill(0);
      textSize(50);
      text(damageDealt,650,250);
      pop();
      currentEasyHealth-=damageDealt;
    }
    
    if (trianglePos==6&&moveSelect!=4){
      push();
      stroke(0)
      fill(0);
      textSize(50);
      text(damageDealt,550,400);
      currentHardHealth-=damageDealt;
      pop();
    }
    if (moveSelect==4){
      push();
      stroke(0)
      fill(0);
      textSize(50);
      playerHealth+=damageDealt;
      text(damageDealt,100,200)
      pop();
    }
    if (currentEasyHealth<0){
      currentEasyHealth=0;
      enemiesKilled++;
      topEnemyX=2000;
    topEnemyY=2000;
    }
    if (currentHardHealth<0){
      currentHardHealth=0;
      enemiesKilled++;
      bottomEnemyX=2000;
    bottomEnemyY=2000;
    }
    if (playerHealth>50){
      playerHealth=50;
    } 
    hasMoved=true;
  }
  
  if (playerTimerLeft==0){
    playerTimer.reset();
    playerTimer.pause();
    ptOn=false;
    print("player turn over");
    hasMoved=false;
    enemyTimer.start();
    etOn=true;
    enemyTurn=1;
    moveSelect=1;
  }
    
  if (enemyTimerLeft<1500&&hasMoved==false){
      push();
      noStroke();
      fill(220);
      rect(315,235,100,100);
      pop();
      if (enemyTurn==1){
      damageDealt=damageCalculate(easyEnemyPower,3);
      }
      else if (enemyTurn==2){
      damageDealt=damageCalculate(hardEnemyPower,3);
      }
    push();
      stroke(0)
      fill(0);
      textSize(50);
      text(damageDealt,350,300);
    pop();
      playerHealth-=damageDealt;
      print(playerHealth);  
      hasMoved=true;
  }  
    
  if (enemyTimerLeft==0){
    if (enemyTurn==1){
    enemyTimer.reset();
    print("enemy 1 turn over");
    if (enemiesKilled==1){
      enemyTimer.pause();
      etOn=false;
      hasMoved=false;
      trianglePos=1;
      triangle(75,750,125,780,75,810);
      battleState=1;
      enemyTurn=0;
    }
      else{
        enemyTurn=2;
        hasMoved=false;
      }
    }
    else if (enemyTurn==2){
    enemyTimer.reset();
    enemyTimer.pause();
      etOn=false;
      hasMoved=false;
    print("enemy 2 turn over");
    trianglePos=1;
    triangle(75,750,125,780,75,810);
    battleState=1;
    enemyTurn=0;
    }
  }
  
  if (currentEasyHealth<=0){
    currentEasyHealth=0;
    topEnemyX=2000;
    topEnemyY=2000;
  }
  if (currentHardHealth<=0){
    currentHardHealth=0;
    bottomEnemyX=2000;
    bottomEnemyY=2000;
  }
    if (enemiesKilled==2){
      secretKillTimer.start();
      sktOn=true;
      if (secretKillTimerLeft==0){
        battleState=5;
        rect(0,0,1000);
        push();
        stroke(0)
        textSize(70);
        fill(0);
        text('Battle Won!',400,500);
        pop();
        battleWonTimer.start();
        bwtOn=true;
        power++;
        enemiesKilled=0;
        xpos=500;
        ypos=500;
        
  }
    }
  
  }
    if(playerHealth <= 0)
    {
      battleState=7;
      inBattle=7;
      battleWonTimer.start();
      push();
      stroke(255,0,0);
      strokeWeight(10);
      line(125,200,200,375);
      line(225,200,100,375);
      pop();
    }
    if (battleWonTimerLeft==0){
      battleWonTimer.pause();
      battleWonTimer.reset();
          battleState=0;
          inBattle=0;
      battleSetup=false;
      trianglePos=1;
      moveSelect=1;
      ultraSecret=0;
      topEnemyX=850;
      topEnemyY=250;
      bottomEnemyX=750;
      bottomEnemyY=400;
        }
  }
  if(inPauseScreen == 1&&battleState==9){
  //creates the interactive pause screen
  inPauseScreen = 1;
  wasPausePressed = true;
  push();
  strokeWeight(0);
  stroke(0,0,0);
  fill(50,50,50,1000);
  rect(0,0,1000,1000);
  stroke(0,0,0);
  fill(255,255,255);
  textSize(50);
  if(highlightPosition == 0)
    {
      strokeWeight(10);
      text('Resume',410,475);
    }
  else
  {
    strokeWeight(0);
    text('Resume',410,475);
  }
  
  if(highlightPosition == 1)
    {
      strokeWeight(10);
      text('Quit',455,575);
    }
  else
  {
    strokeWeight(0);
    text('Quit',455,575);
  }
  pop();
  }
  if(battleWonTimerLeft==0&&battleState==7){
      
    background(220);
    fill(0);
    rect(0,0,1000,1000);
    strokeWeight(2);
    stroke(0);
    fill(225);
    textSize(100);
    text('Game Over',250,175);
    text('Press \"R\"',265,375);
    text('To Try Again',225,575);
    text('Or Q to quit',225,775);
      }
  if(bye==1){
    describe('See ya!',LABEL);
    remove();

  }
}

//trianglePos/moveSelect 1/2/3/4 coresponds to A/B/C/D, tiranglePos 5/6 corresponds to top/bottom enemy

function keyPressed() {
  if(inBattle==0&&battleState!=9){
     if (key == 'w') {
    movingUp = true;
  }
  if (key == 'a') {
    movingLeft = true;
  }
  if (key == 's') {
    movingDown = true;
  }
  if (key == 'd') {
    movingRight = true;
  }
  }
  if (inBattle==1 && battleState==1){

    if (keyCode === LEFT_ARROW) {
      if (secretKey==2) {
      secretKey=3;
      print(secretKey);
      }
      if (trianglePos == 2) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
      }
    } 
    else if (keyCode === RIGHT_ARROW) {
      if (secretKey==3) {
      secretKey=4;
      print(secretKey);
      }
        if (trianglePos == 1)
          {
            //move to B
            eraseTriangle();
            triangle(525,750,575,780,525,810);
            trianglePos=2;
          }
      if (trianglePos == 3)
          {
            //move to D
            eraseTriangle();
            triangle(525,850,575,880,525,910);
            trianglePos=4;
      }
    }
    else if (keyCode === UP_ARROW) {
      secretKey=1;
      print(secretKey);
      if (trianglePos == 3) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to B
        eraseTriangle();
        triangle(525,750,575,780,525,810);
        trianglePos=2;
      }
    }
    else if (keyCode === DOWN_ARROW) {
      if (secretKey==1) {
      secretKey=2;
      print(secretKey);
      }
      if (trianglePos == 1) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
          }
      if (trianglePos == 2) {
        //move to D
        eraseTriangle();
        triangle(525,850,575,880,525,910);
        trianglePos=4;
      }
    }
    
    else if (keyCode === 32){
    if (secretKey==4){
      ultraSecret++;
      secretKey=0;
      }
      if (ultraSecret>=5){
        secretKillTimer.start();
        sktOn=true;
        push();
        noStroke();
        fill(255,0,0);
        rect(0,0,1000,600);
        pop();
        text('ANNIHILATE!!!',300,100);
        currentEasyHealth=0;
        currentHardHealth=0;
        enemiesKilled=2;
      }
      if (trianglePos == 1||2||3||4){
        moveSelect=trianglePos;
        if(currentEasyHealth==0){
        trianglePos=6;
        }
        else {
          trianglePos=5;
        }
        battleState=2;
      }
    }
        else {
    secretKey=0;
    }
  }
  if (inBattle==1 && battleState==2){
    //erase all triangles from move select
     push();
      stroke(300);
      strokeWeight(10);
      triangle(75,750,125,780,75,810);
      triangle(525,750,575,780,525,810);
      triangle(75,850,125,880,75,910);
      triangle(525,850,575,880,525,910);
      pop();
    //create triangles for enemies
    if (currentEasyHealth>0){
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(700,220,750,250,700,280);
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else {
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(600,370,650,400,600,430);  
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);
      pop();
    }

    if (keyCode===DOWN_ARROW && currentHardHealth>0){
      trianglePos=6;
      triangle(600,370,650,400,600,430);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);  
      pop();
    }
    if (keyCode===UP_ARROW && currentEasyHealth>0){
      trianglePos=5;
      triangle(700,220,750,250,700,280);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else if (keyCode===85){  
    battleState=3; 
    }
    //backspace to go back to move select
    else if (keyCode===8){
      trianglePos=1;
      moveSelect=0;
      triangle(75,750,125,780,75,810);
      push();
      stroke(220);
      fill(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      triangle(700,220,750,250,700,280);
      pop();
      battleState=1;
    }
    
  }
  if (inBattle==1 && battleState==3){
     //calculate damage
    var damage;
    if (moveSelect==1){ 
    damageDealt = damageCalculate(power,3);
    }
    if (moveSelect==2){ 
    damageDealt = damageCalculate(power,1);
    }
    if (moveSelect==3){ 
    damageDealt = damageCalculate(power,6);
    }
    if (moveSelect==4){ 
    damageDealt = maxPlayerHealth*0.2;
    }
    push();
    noStroke();
    fill(220);
    rect(0,0,1000,600);
    pop();
    
    //restart mode/move to enemy turn
    playerTimer.start();
    ptOn=true;
    eraseTriangle();
    battleState= 4;
    }
  if((key == 'p') && (wasPausePressed == false)) {
  inPauseScreen = 1;
  previousBattleState=battleState;
  battleState=9;
  previousinBattle=inBattle;
  inBattle=9;
  if (ptOn==true){
  playerTimer.pause();
  }
  if (etOn==true){
  enemyTimer.pause();
  }
  if (sktOn==true){
  secretKillTimer.pause();
  }
  if (bwtOn==true){
  battleWonTimer.pause();
  }
  }
  if((inPauseScreen == 1) && (key == 'w')) {
    highlightPosition = 0;
  }
  else if((inPauseScreen == 1) && (key == 's')) {
    highlightPosition = 1;
  }
  if((inPauseScreen == 1) && (highlightPosition == 0) && (keyCode === ENTER))
    {
      if (ptOn==true){
      playerTimer.start();
      }
      if (etOn==true){
      enemyTimer.start();
      }
      if (sktOn==true){
      secretKillTimer.start();
      }
      if (bwtOn==true){
      battleWonTimer.start();
      }
      battleSetup=false;
      inPauseScreen = 0;
      wasPausePressed = false;
      battleState=previousBattleState;
      inBattle=previousinBattle;
    }
  else if((inPauseScreen == 1) && (highlightPosition == 1) && (keyCode === ENTER)) {
    bye=1;
  }
  if (key == 'q'&& battleState==7){
    bye=1;
  }
  if (key == 'h'&&inBattle==8&&battleState==8){
    battleState=0;
    inBattle=0;
  }
  if (key=='r' && battleState==7){
    inBattle=0;
    battleState=0;
 previousBattleState=0;
 trianglePos = 1;
 power = 10;
 secretKey = 0;
 ultraSecret = 0;
 maxPlayerHealth= 50;
 playerHealth = 50;
 easyEnemyHealth = 30;
 currentEasyHealth=30;
 hardEnemyHealth = 70;
 currentHardHealth=70;
 enemiesKilled=0;
 topEnemyX=850;
 topEnemyY=250;
 bottomEnemyX=750;
 bottomEnemyY=400;
 moveSelect = 1;
 ptOn=false;
 etOn=false;
 sktOn=false;
bwtOn=false;
enemyTurn=0;
hasMoved=false;
enemy1Xpos=200;
enemy1Ypos=200;
enemy2Xpos=800;
enemy2Ypos=800;
battleSetup=false;
bye=0;
  }
  
}

function keyReleased() {
  if (key == 'w') {
    movingUp = false;
  }
  if (key == 'a') {
    movingLeft = false;
  }
  if (key == 's') {
    movingDown = false;
  }
  if (key == 'd') {
    movingRight = false;
  }
}


/*function setup() {

	var strength = 132;

	// call function and pass the variable yourWeight into it

	var damageNumber = calculateDam(strength);

	// output variable marsWeight to console

	print(damageNumber);
}

// function calculateMars accepts a number and assigns the variable 'w' to it

function calculateDam(w) {

// the function uses this 'w' variable value in calculating a variable call newWeight

	var damage = w * 0.38;

// the variable newWeight value is returned  to line 9 where the function was called, there it is assigned to the variable marsWeight

	return damage;
}
*/